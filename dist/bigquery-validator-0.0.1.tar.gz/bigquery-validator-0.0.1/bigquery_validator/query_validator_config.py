params = {
    'sbtech_project': 'gamesys-eu-dev-sbtech-data',
    'lithium_project': 'ls-africa-data-eu-dev'
}
